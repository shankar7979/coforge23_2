package io.caused.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot3JwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
